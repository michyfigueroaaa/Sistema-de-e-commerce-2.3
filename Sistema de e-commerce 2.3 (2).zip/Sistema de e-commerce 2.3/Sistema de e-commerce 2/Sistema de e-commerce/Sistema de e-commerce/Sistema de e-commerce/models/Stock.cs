﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    internal class Stock
    {
        public int producto_id { get; set; }
        public int cantidad { get; set; }

    }
}
