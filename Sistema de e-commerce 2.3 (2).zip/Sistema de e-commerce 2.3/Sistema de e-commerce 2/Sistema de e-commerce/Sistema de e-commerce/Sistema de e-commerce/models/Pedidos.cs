﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    internal class Pedidos
    {
        public int id { get; set; }
        public DateTime fecha { get; set; }
        public string estado { get; set; }
        public string direccion_envio { get; set; }
        public string metodo_pago { get; set; }
        public decimal total { get; set; }
        public string NombreCliente { get; set; }
        public List<DetallePedido> Detalles { get; set; }
        public DateTime fecha_envio { get; set; }
    }
}
