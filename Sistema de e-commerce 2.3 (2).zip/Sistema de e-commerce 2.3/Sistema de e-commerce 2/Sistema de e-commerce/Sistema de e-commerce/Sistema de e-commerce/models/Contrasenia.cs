﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    public class Contrasenia
    {
        public int Id { get; set; }
        public string entidadTipo { get; set; }
        public string entidadId { get; set; }
        public string hash { get; set; }
        public DateTime fechaCreacion { get; set; }
        public bool esActiva { get; set; }
    }
}
