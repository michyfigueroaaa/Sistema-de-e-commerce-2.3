﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    public class Usuarios
    {
        public List<Usuarios> usuarios { get; set; }
        public string idUsuario { get; set; }
        public string nombre { get; set; }
        public string email { get; set; }
    }
}
