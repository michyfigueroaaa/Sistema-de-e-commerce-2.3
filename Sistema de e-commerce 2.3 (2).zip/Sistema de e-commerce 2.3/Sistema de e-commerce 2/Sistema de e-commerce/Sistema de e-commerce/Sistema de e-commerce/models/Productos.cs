﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    public class Productos
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public string categoria { get; set; }
        public string estilo { get; set; }
        public string talla { get; set; }
        public string color { get; set; }
        public decimal precio { get; set; }
        public int cantidad { get; set; }
    }
}
