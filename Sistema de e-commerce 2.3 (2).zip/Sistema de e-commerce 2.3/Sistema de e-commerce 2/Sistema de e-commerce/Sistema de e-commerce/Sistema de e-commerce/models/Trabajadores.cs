﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    public class Trabajadores
    {
        public List<Trabajadores> trabajadores { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string email { get; set; }
        public string cargo { get; set; }
        public string contrasenia { get; set; }
        public string idEmpleado { get; set; }
    }

}
