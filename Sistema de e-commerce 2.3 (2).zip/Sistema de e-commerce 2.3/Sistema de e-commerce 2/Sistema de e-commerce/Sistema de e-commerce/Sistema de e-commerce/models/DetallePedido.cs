﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    internal class DetallePedido
    {
        public int id { get; set; }
        public int pedido_id { get; set; }
        public int producto_id { get; set; }
        public int cantidad { get; set; }
        public decimal precio_unitario { get; set; }
    }
}
