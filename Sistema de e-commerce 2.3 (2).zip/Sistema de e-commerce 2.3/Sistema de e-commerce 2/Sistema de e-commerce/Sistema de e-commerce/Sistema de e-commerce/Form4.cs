﻿using Sistema_de_e_commerce.models;
using Sistema_de_e_commerce.repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sistema_de_e_commerce
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form3 nuevoFormulario = new Form3(); // Crear instancia del nuevo form
            nuevoFormulario.Show();              // Mostrar el nuevo form
            this.Hide();                         // Opcional: ocultar el actual

        }

        private async void Form4_Load(object sender, EventArgs e)
        {
            await CargarPedidosEnGrid();

            var repo = new PedidoRepository();
            List<Pedidos> pedidos = await repo.ObtenerPedidosConDetallesAsync();

            comboBox1.DataSource = pedidos;
            comboBox1.DisplayMember = "id";
            comboBox1.ValueMember = "id";

            await RefrescarTextBoxesAsync();

        }

        private async Task CargarPedidosEnGrid()
        {
            var repo = new PedidoRepository();
            var lista = await repo.ObtenerPedidosConDetallesAsync();
            dataGridView1.DataSource = lista;
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null)
            {
                MessageBox.Show("Seleccione un pedido.");
                return;
            }

            int pedidoId = (int)comboBox1.SelectedValue;

            var repo = new PedidoRepository();

            try
            {
                bool pedidoEnviado = await repo.CambiarEstadoPedidoAsync(pedidoId, "Enviado");

                if (pedidoEnviado)
                {
                    MessageBox.Show("Stock actualizado correctamente.");
                    await CargarPedidosEnGrid();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el pedido.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el pedido: " + ex.Message);
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null)
            {
                MessageBox.Show("Seleccione un pedido.");
                return;
            }

            int pedidoId = (int)comboBox1.SelectedValue;

            var repo = new PedidoRepository();

            try
            {
                bool pedidoEnviado = await repo.CambiarEstadoPedidoAsync(pedidoId, "Entregado");

                if (pedidoEnviado)
                {
                    MessageBox.Show("Stock actualizado correctamente.");
                    await CargarPedidosEnGrid();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el pedido.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el pedido: " + ex.Message);
            }

        }

        private async Task RefrescarTextBoxesAsync()
        {
            var repo = new PedidoRepository();

            var proximoEnviar = await repo.ObtenerProximoParaEnviarAsync();
            var proximoConfirmar = await repo.ObtenerProximoParaConfirmarAsync();

            txtSigEnviar.Text = proximoEnviar != null ? $"Pedido #{proximoEnviar.id}" : "‑";
            txtSigConfirmar.Text = proximoConfirmar != null ? $"Pedido #{proximoConfirmar.id}" : "‑";
        }

        private async void btnEnviarSig_Click(object sender, EventArgs e)
        {
            var repo = new PedidoRepository();
            var pedido = await repo.ObtenerProximoParaEnviarAsync();

            if (pedido == null)
            {
                MessageBox.Show("No hay pedidos pendientes para enviar.");
                return;
            }

            if (await repo.CambiarEstadoPedidoAsync(pedido.id, "Enviado"))
                MessageBox.Show($"Pedido {pedido.id} marcado como Enviado.");
            else
                MessageBox.Show("No se pudo actualizar el pedido.");

            await CargarPedidosEnGrid();
            await RefrescarTextBoxesAsync();
        }

        private async void btnConfirmarSig_Click(object sender, EventArgs e)
        {
            var repo = new PedidoRepository();
            var pedido = await repo.ObtenerProximoParaConfirmarAsync();

            if (pedido == null)
            {
                MessageBox.Show("No hay envíos pendientes de confirmar.");
                return;
            }

            if (await repo.CambiarEstadoPedidoAsync(pedido.id, "Entregado"))
                MessageBox.Show($"Pedido {pedido.id} marcado como Entregado.");
            else
                MessageBox.Show("No se pudo actualizar el pedido.");

            await CargarPedidosEnGrid();
            await RefrescarTextBoxesAsync();
        }
    }
}
