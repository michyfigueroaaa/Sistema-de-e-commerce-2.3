﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.repository
{
    public class TrabajadoresRepository
    {
        public async Task<Trabajadores> ObtenerPorIdAsync(string id)
        {
            Trabajadores trabajadores = null;

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("SELECT Nombre, Apellido, Cargo, IdEmpleado FROM trabajadores WHERE IdEmpleado = @IdEmpleado", conexion))
                {
                    comando.Parameters.AddWithValue("@IdEmpleado", id);
                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        if (await lector.ReadAsync())
                        {
                            trabajadores = new Trabajadores
                            {
                                nombre = lector["Nombre"].ToString(),
                                apellido = lector["Apellido"].ToString(),
                                cargo = lector["Cargo"].ToString(),
                                idEmpleado = lector["IdEmpleado"].ToString(),
                            };
                        }
                    }
                }
            }

            return trabajadores;
        }

    }
}
