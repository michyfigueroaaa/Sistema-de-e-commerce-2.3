﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.repository
{
    internal class PedidoRepository
    {
        public async Task<List<Pedidos>> ObtenerPedidosConDetallesAsync()
        {
            var pedidosDict = new Dictionary<int, Pedidos>();

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();

                const string query = @"
                    SELECT 
                        p.id AS PedidoId, p.fecha, p.estado, p.direccion_envio, 
                        p.metodo_pago, p.total,
                        u.Nombre AS NombreCliente,
                        dp.producto_id, dp.cantidad, dp.precio_unitario
                    FROM pedidos p
                    INNER JOIN usuarios u      ON p.cliente_id = u.IdUsuario
                    LEFT JOIN detalle_pedidos dp ON p.id = dp.pedido_id
                    ORDER BY p.id;";

                using (SqlCommand comando = new SqlCommand(query, conexion))
                using (SqlDataReader reader = await comando.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int pedidoId = reader.GetInt32(reader.GetOrdinal("PedidoId"));

                        if (!pedidosDict.ContainsKey(pedidoId))
                        {
                            pedidosDict[pedidoId] = new Pedidos
                            {
                                id = pedidoId,
                                fecha = reader.GetDateTime(reader.GetOrdinal("fecha")),
                                estado = reader["estado"].ToString(),
                                direccion_envio = reader["direccion_envio"].ToString(),
                                metodo_pago = reader["metodo_pago"].ToString(),
                                total = reader.GetDecimal(reader.GetOrdinal("total")),
                                NombreCliente = reader["NombreCliente"].ToString(),
                                Detalles = new List<DetallePedido>()
                            };
                        }

                        // Agregar detalle si existe
                        if (!reader.IsDBNull(reader.GetOrdinal("producto_id")))
                        {
                            pedidosDict[pedidoId].Detalles.Add(new DetallePedido
                            {
                                producto_id = reader.GetInt32(reader.GetOrdinal("producto_id")),
                                cantidad = reader.GetInt32(reader.GetOrdinal("cantidad")),
                                precio_unitario = reader.GetDecimal(reader.GetOrdinal("precio_unitario"))
                            });
                        }
                    }
                }
            }
            return pedidosDict.Values.ToList();
        }

        public async Task<bool> CambiarEstadoPedidoAsync(int pedidoId, string nuevoEstado)
        {
            var estadosValidos = new HashSet<string> { "Pendiente", "Enviado", "Entregado" };
            if (!estadosValidos.Contains(nuevoEstado))
                throw new ArgumentException("Estado no válido. Debe ser 'Pendiente', 'Enviado' o 'Entregado'.");

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();

                const string sql = "UPDATE pedidos SET estado = @estado WHERE id = @id;";

                using (SqlCommand comando = new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue("@estado", nuevoEstado);
                    comando.Parameters.AddWithValue("@id", pedidoId);

                    int filasAfectadas = await comando.ExecuteNonQueryAsync();
                    return filasAfectadas > 0;
                }
            }
        }

        ///Próximo a ENVIAR (más antiguo con estado Pendiente, ordenado por fecha)
        public async Task<Pedidos> ObtenerProximoParaEnviarAsync()
        {
            const string sql = @"
        SELECT TOP 1 * FROM pedidos
        WHERE estado = 'Pendiente'
        ORDER BY fecha ASC";

            return await ObtenerPedidoSimpleAsync(sql);
        }

        ///Próximo a CONFIRMAR (más antiguo con estado Enviado, ordenado por fecha_envio)
        public async Task<Pedidos> ObtenerProximoParaConfirmarAsync()
        {
            const string sql = @"
        SELECT TOP 1 * FROM pedidos
        WHERE estado = 'Enviado'
        ORDER BY fecha_envio ASC";

            return await ObtenerPedidoSimpleAsync(sql);
        }

        private async Task<Pedidos> ObtenerPedidoSimpleAsync(string sql)
        {
            using (SqlConnection con = ConexionBD.ObtenerConexion())
            {
                await con.OpenAsync();
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataReader r = await cmd.ExecuteReaderAsync())
                {
                    if (await r.ReadAsync())
                    {
                        return new Pedidos
                        {
                            id = r.GetInt32(r.GetOrdinal("id")),
                            fecha = r.GetDateTime(r.GetOrdinal("fecha")),
                            estado = r["estado"].ToString(),
                        };
                    }
                }
            }
            return null;   // sin pedidos disponibles
        }

    }

}
