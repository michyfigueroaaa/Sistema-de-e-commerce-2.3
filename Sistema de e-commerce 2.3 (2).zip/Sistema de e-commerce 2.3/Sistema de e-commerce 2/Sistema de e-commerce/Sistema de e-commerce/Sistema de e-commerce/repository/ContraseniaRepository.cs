﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.repository
{
    public class ContraseniaRepository
    {
        public async Task<int> InsertarContrasenia(Contrasenia contrasenia)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                const string query = @"
                    INSERT INTO contrasenia (entidad_tipo, entidad_id, hash, es_activa)
                    VALUES (@EntidadTipo, @EntidadId, @Hash, @EsActiva);";

                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@EntidadTipo", contrasenia.entidadTipo);
                    comando.Parameters.AddWithValue("@EntidadId", contrasenia.entidadId);
                    comando.Parameters.AddWithValue("@Hash", contrasenia.hash);
                    comando.Parameters.AddWithValue("@EsActiva", contrasenia.esActiva);

                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<Contrasenia> ObtenerPorEntidadIdAsync(string entidad_id)
        {
            Contrasenia contrasenia = null;

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                const string sql = @"
                    SELECT id, entidad_tipo, entidad_id, hash, es_activa
                    FROM contrasenia
                    WHERE entidad_id = @entidad_id;";

                using (SqlCommand comando = new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue("@entidad_id", entidad_id);

                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        if (await lector.ReadAsync())
                        {
                            contrasenia = new Contrasenia
                            {
                                Id = (int)lector["id"],
                                entidadTipo = lector["entidad_tipo"].ToString(),
                                entidadId = lector["entidad_id"].ToString(),
                                hash = lector["hash"].ToString(),
                                esActiva = (bool)lector["es_activa"]
                            };
                        }
                    }
                }
            }
            return contrasenia;
        }

        public async Task<Contrasenia> ObtenerPorHashAsync(string hash)
        {
            Contrasenia contrasenia = null;

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                const string sql = @"
                    SELECT id, entidad_tipo, entidad_id, hash, fecha_creacion, es_activa
                    FROM contrasenia
                    WHERE hash = @hash;";

                using (SqlCommand comando = new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue("@hash", hash);

                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        if (await lector.ReadAsync())
                        {
                            contrasenia = new Contrasenia
                            {
                                Id = (int)lector["id"],
                                entidadTipo = lector["entidad_tipo"].ToString(),
                                entidadId = lector["entidad_id"].ToString(),
                                hash = lector["hash"].ToString(),
                                fechaCreacion = (DateTime)lector["fecha_creacion"],
                                esActiva = (bool)lector["es_activa"]
                            };
                        }
                    }
                }
            }
            return contrasenia;
        }
    }
}
