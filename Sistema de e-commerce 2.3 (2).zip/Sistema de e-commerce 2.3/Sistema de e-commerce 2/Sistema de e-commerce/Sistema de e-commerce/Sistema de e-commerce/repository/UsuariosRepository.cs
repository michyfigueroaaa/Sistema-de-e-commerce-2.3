﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Sistema_de_e_commerce.repository
{
    public class UsuariosRepository
    {

        public async Task<List<Usuarios>> ObtenerTodosAsync()
        {
            var usuarios = new List<Usuarios>();

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("SELECT IdUsuario, Nombre, Email FROM usuarios", conexion))
                {
                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        while (await lector.ReadAsync())
                        {
                            usuarios.Add(new Usuarios
                            {
                                idUsuario = lector["IdUsuario"].ToString(),
                                nombre = lector["Nombre"].ToString(),
                                email = lector["Email"].ToString()
                            });
                        }
                    }
                }
            }

            return usuarios;
        }

        public async Task<Usuarios> ObtenerPorIdAsync(string idUsuario)
        {
            Usuarios usuario = null;

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("SELECT IdUsuario, Nombre, Email FROM usuarios WHERE IdUsuario = @IdUsuario", conexion))
                {
                    comando.Parameters.AddWithValue("@IdUsuario", idUsuario);
                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        if (await lector.ReadAsync())
                        {
                            usuario = new Usuarios
                            {
                                idUsuario = lector["IdUsuario"].ToString(),
                                nombre = lector["Nombre"].ToString(),
                                email = lector["Email"].ToString()
                            };
                        }
                    }
                }
            }

            return usuario;
        }

        public async Task<Usuarios> ObtenerPorEmailAsync(string email)
        {
            Usuarios usuario = null;

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("SELECT IdUsuario, Nombre, Email FROM usuarios WHERE Email = @Email", conexion))
                {
                    comando.Parameters.AddWithValue("@Email", email);
                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        if (await lector.ReadAsync())
                        {
                            usuario = new Usuarios
                            {
                                idUsuario = lector["IdUsuario"].ToString(),
                                nombre = lector["Nombre"].ToString(),
                                email = lector["Email"].ToString()
                            };
                        }
                    }
                }
            }

            return usuario;
        }

        public async Task<int> AgregarAsync(Usuarios usuario)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("INSERT INTO usuarios (IdUsuario, Nombre, Email) VALUES (@IdUsuario, @Nombre, @Email)", conexion))
                {
                    comando.Parameters.AddWithValue("@IdUsuario", usuario.idUsuario);
                    comando.Parameters.AddWithValue("@Nombre", usuario.nombre);
                    comando.Parameters.AddWithValue("@Email", usuario.email);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<int> ActualizarAsync(Usuarios usuario)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("UPDATE usuarios SET Nombre = @Nombre, Email = @Email WHERE IdUsuario = @IdUsuario", conexion))
                {
                    comando.Parameters.AddWithValue("@IdUsuario", usuario.idUsuario);
                    comando.Parameters.AddWithValue("@Nombre", usuario.nombre);
                    comando.Parameters.AddWithValue("@Email", usuario.email);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<int> EliminarAsync(string idUsuario)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("DELETE FROM usuarios WHERE IdUsuario = @IdUsuario", conexion))
                {
                    comando.Parameters.AddWithValue("@IdUsuario", idUsuario);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }
    }
}
