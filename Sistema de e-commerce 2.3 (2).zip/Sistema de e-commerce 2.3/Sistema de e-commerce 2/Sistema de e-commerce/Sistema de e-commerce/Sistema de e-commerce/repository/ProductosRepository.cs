﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.repository
{
    internal class ProductosRepository
    {

        public async Task<List<Productos>> ObtenerTodosAsync()
        {
            var productos = new List<Productos>();

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand(@"
                SELECT p.id, p.nombre, p.descripcion, p.categoria, p.estilo,
                p.talla, p.color, p.precio, s.cantidad FROM productos p 
                LEFT JOIN stock s ON p.id = s.producto_id", 
                conexion)){
                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        while (await lector.ReadAsync())
                        {
                            productos.Add(new Productos
                            {
                                id = (int)lector["id"],
                                nombre = lector["nombre"].ToString(),
                                descripcion = lector["descripcion"].ToString(),
                                categoria = lector["categoria"].ToString(),
                                estilo = lector["estilo"].ToString(),
                                talla = lector["talla"].ToString(),
                                color = lector["color"].ToString(),
                                precio = (decimal)lector["precio"],
                                cantidad = lector["cantidad"] == DBNull.Value ? 0 : Convert.ToInt32(lector["cantidad"])
                            });
                        }
                    }
                }
            }

            return productos;
        }

        public async Task<int> AgregarAsync(Productos producto)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlTransaction transaccion = conexion.BeginTransaction())
                {
                    try
                    {
                        int nuevoId;

                        using (SqlCommand comando = new SqlCommand(@"
                    INSERT INTO productos (nombre, descripcion, categoria, estilo, talla, color, precio)
                    VALUES (@nombre, @descripcion, @categoria, @estilo, @talla, @color, @precio);
                    SELECT SCOPE_IDENTITY();", conexion, transaccion))
                        {
                            comando.Parameters.AddWithValue("@nombre", producto.nombre);
                            comando.Parameters.AddWithValue("@descripcion", producto.descripcion);
                            comando.Parameters.AddWithValue("@categoria", producto.categoria);
                            comando.Parameters.AddWithValue("@estilo", producto.estilo);
                            comando.Parameters.AddWithValue("@talla", producto.talla);
                            comando.Parameters.AddWithValue("@color", producto.color);
                            comando.Parameters.AddWithValue("@precio", producto.precio);

                            // Obtener el ID generado automáticamente
                            object result = await comando.ExecuteScalarAsync();
                            nuevoId = Convert.ToInt32(result);
                        }

                        using (SqlCommand comandoStock = new SqlCommand(@"
                    INSERT INTO stock (producto_id, cantidad)
                    VALUES (@producto_id, @cantidad)", conexion, transaccion))
                        {
                            comandoStock.Parameters.AddWithValue("@producto_id", nuevoId);
                            comandoStock.Parameters.AddWithValue("@cantidad", producto.cantidad);
                            await comandoStock.ExecuteNonQueryAsync();
                        }

                        transaccion.Commit();
                        return 1;
                    }
                    catch
                    {
                        transaccion.Rollback();
                        return 0;
                    }
                }
            }
        }



        public async Task<int> ActualizarAsync(Productos producto)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlTransaction transaccion = conexion.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand comando = new SqlCommand(@"
                    UPDATE productos
                    SET nombre = @nombre, descripcion = @descripcion, categoria = @categoria,
                        estilo = @estilo, talla = @talla, color = @color, precio = @precio
                    WHERE id = @id", conexion, transaccion))
                        {
                            comando.Parameters.AddWithValue("@id", producto.id);
                            comando.Parameters.AddWithValue("@nombre", producto.nombre);
                            comando.Parameters.AddWithValue("@descripcion", producto.descripcion);
                            comando.Parameters.AddWithValue("@categoria", producto.categoria);
                            comando.Parameters.AddWithValue("@estilo", producto.estilo);
                            comando.Parameters.AddWithValue("@talla", producto.talla);
                            comando.Parameters.AddWithValue("@color", producto.color);
                            comando.Parameters.AddWithValue("@precio", producto.precio);
                            await comando.ExecuteNonQueryAsync();
                        }

                        using (SqlCommand comandoStock = new SqlCommand(@"
                    UPDATE stock
                    SET cantidad = @cantidad
                    WHERE producto_id = @producto_id", conexion, transaccion))
                        {
                            comandoStock.Parameters.AddWithValue("@producto_id", producto.id);
                            comandoStock.Parameters.AddWithValue("@cantidad", producto.cantidad);
                            await comandoStock.ExecuteNonQueryAsync();
                        }

                        transaccion.Commit();
                        return 1;
                    }
                    catch
                    {
                        transaccion.Rollback();
                        return 0;
                    }
                }
            }
        }


        public async Task<int> EliminarAsync(string id)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("DELETE FROM productos WHERE id = @id", conexion))
                {
                    comando.Parameters.AddWithValue("@id", id);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }

    }
}
