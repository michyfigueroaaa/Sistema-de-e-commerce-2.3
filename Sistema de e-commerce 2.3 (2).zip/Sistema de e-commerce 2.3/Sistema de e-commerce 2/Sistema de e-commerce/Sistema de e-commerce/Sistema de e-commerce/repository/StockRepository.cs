﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.repository
{
    internal class StockRepository
    {

        public async Task<Stock> ObtenerPorProductoIdAsync(int productoId)
        {
            Stock stock = null;

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("SELECT producto_id, cantidad FROM stock WHERE producto_id = @producto_id", conexion))
                {
                    comando.Parameters.AddWithValue("@producto_id", productoId);
                    using (SqlDataReader lector = await comando.ExecuteReaderAsync())
                    {
                        if (await lector.ReadAsync())
                        {
                            stock = new Stock
                            {
                                producto_id = Convert.ToInt32(lector["producto_id"]),
                                cantidad = Convert.ToInt32(lector["cantidad"])
                            };
                        }
                    }
                }
            }

            return stock;
        }

        public async Task<int> AgregarAsync(Stock stock)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("INSERT INTO stock (producto_id, cantidad) VALUES (@producto_id, @cantidad)", conexion))
                {
                    comando.Parameters.AddWithValue("@producto_id", stock.producto_id);
                    comando.Parameters.AddWithValue("@cantidad", stock.cantidad);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<int> ActualizarCantidadAsync(string productoId, int nuevaCantidad)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("UPDATE stock SET cantidad = @cantidad WHERE producto_id = @producto_id", conexion))
                {
                    comando.Parameters.AddWithValue("@producto_id", productoId);
                    comando.Parameters.AddWithValue("@cantidad", nuevaCantidad);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }

        public async Task<int> EliminarPorProductoIdAsync(string productoId)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                await conexion.OpenAsync();
                using (SqlCommand comando = new SqlCommand("DELETE FROM stock WHERE producto_id = @producto_id", conexion))
                {
                    comando.Parameters.AddWithValue("@producto_id", productoId);
                    return await comando.ExecuteNonQueryAsync();
                }
            }
        }
    }
}
