﻿using Sistema_de_e_commerce.models;
using Sistema_de_e_commerce.repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sistema_de_e_commerce
{
    public partial class Form3 : Form

    {
        ProductosRepository productosRepository = null;
        StockRepository stockRepository = null;
        private string productoIdSeleccionado = null;
        public Form3()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private async void Form3_Load(object sender, EventArgs e)
        {
            await CargarProductosEnGrid();

            productosRepository = new ProductosRepository();
            List<Productos> productos = await productosRepository.ObtenerTodosAsync();
            comboBox5.SelectedIndexChanged -= comboBox5_SelectedIndexChanged;

            comboBox5.DataSource = productos;
            comboBox5.DisplayMember = "nombre";
            comboBox5.ValueMember = "id";

            comboBox5.SelectedIndexChanged += comboBox5_SelectedIndexChanged;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btnPedidosRealizados_Click(object sender, EventArgs e)
        {
            Form4 nuevoFormulario = new Form4(); // Crear instancia del nuevo form
            nuevoFormulario.Show();              // Mostrar el nuevo form
            this.Hide();                         // Opcional: ocultar el actual

        }

        private async Task CargarProductosEnGrid()
        {
            var repo = new ProductosRepository();
            var lista = await repo.ObtenerTodosAsync();
            dataGridView1.DataSource = lista;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                LimpiarFormulario();
                DataGridViewRow fila = dataGridView1.Rows[e.RowIndex];

                productoIdSeleccionado = fila.Cells["id"].Value?.ToString();

                textBox1.Text = fila.Cells["nombre"].Value?.ToString();
                textBox2.Text = fila.Cells["descripcion"].Value?.ToString();
                comboBox4.SelectedItem = fila.Cells["categoria"].Value?.ToString();
                comboBox2.SelectedItem = fila.Cells["estilo"].Value?.ToString();
                comboBox3.SelectedItem = fila.Cells["talla"].Value?.ToString();
                textBox4.Text = fila.Cells["color"].Value?.ToString();
                numericUpDown1.Value = Convert.ToDecimal(fila.Cells["precio"].Value);
                numericUpDown2.Value = Convert.ToDecimal(fila.Cells["cantidad"].Value);


            }
        }

        private void LimpiarFormulario()
        {
            textBox1.Clear();
            textBox2.Clear();
            comboBox4.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;
            textBox4.Clear();
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
        }

        private async void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedValue == null)
                return;

            stockRepository = new StockRepository();

            try
            {
                Productos productoseleccionado = new Productos();
                productoseleccionado.id = Convert.ToInt32(comboBox5.SelectedValue);
                int productoId = productoseleccionado.id;
                Stock stock = await stockRepository.ObtenerPorProductoIdAsync(productoId);

                if (stock != null)
                {
                    numericUpDown3.Value = Convert.ToInt32(stock.cantidad);
                }
                else
                {
                    numericUpDown3.Value = 0; 
                    MessageBox.Show("No hay stock registrado para este producto.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el stock:\n" + ex.Message + "\n\n" + ex.StackTrace);
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            try {
                var producto = new Productos
                {
                    nombre = textBox1.Text.Trim(),
                    descripcion = textBox2.Text.Trim(),
                    categoria = comboBox4.SelectedItem?.ToString() ?? "",
                    estilo = comboBox2.SelectedItem?.ToString() ?? "",
                    talla = comboBox3.SelectedItem?.ToString() ?? "",
                    color = textBox4.Text.Trim(),
                    precio = numericUpDown1.Value,
                    cantidad = (int)numericUpDown2.Value
                };

                productosRepository = new ProductosRepository();
                int idproducto = await productosRepository.AgregarAsync(producto);

                MessageBox.Show("Producto agregado correctamente");
                LimpiarFormulario();
                await CargarProductosEnGrid();  // Recargar el grid para actualizar la lista
            }
            catch
            {
                MessageBox.Show("Error al agregar el producto");
            }
            
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(productoIdSeleccionado))
            {
                MessageBox.Show("Selecciona un producto para actualizar.");
                return;
            }

            var producto = new Productos
            {
                id = int.Parse(productoIdSeleccionado),
                nombre = textBox1.Text.Trim(),
                descripcion = textBox2.Text.Trim(),
                categoria = comboBox4.SelectedItem?.ToString() ?? "",
                estilo = comboBox2.SelectedItem?.ToString() ?? "",
                talla = comboBox3.SelectedItem?.ToString() ?? "",
                color = textBox4.Text.Trim(),
                precio = numericUpDown1.Value,
                cantidad = (int)numericUpDown2.Value
            };

            var repo = new ProductosRepository();
            int resultado = await repo.ActualizarAsync(producto);

            if (resultado > 0)
            {
                MessageBox.Show("Producto actualizado correctamente");
                LimpiarFormulario();
                await CargarProductosEnGrid();
                productoIdSeleccionado = null; // Limpias el id seleccionado
            }
            else
            {
                MessageBox.Show("Error al actualizar el producto");
            }

        }

        private async void button3_Click(object sender, EventArgs e)
        {
            if (comboBox5.SelectedValue == null)
            {
                MessageBox.Show("Seleccione un producto.");
                return;
            }

            int productoId = (int)comboBox5.SelectedValue;
            int nuevaCantidad = (int)numericUpDown3.Value;

            stockRepository = new StockRepository();

            try
            {
                int filasAfectadas = await stockRepository.ActualizarCantidadAsync(productoId.ToString(), nuevaCantidad);

                if (filasAfectadas > 0)
                {
                    MessageBox.Show("Stock actualizado correctamente.");
                    await CargarProductosEnGrid();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el stock. Verifique que el producto exista en la tabla de stock.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el stock: " + ex.Message);
            }

        }
    }
}
