﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_e_commerce.utils
{
    public static class MessageBoxHelper
    {
        public static void MostrarLoginExitoso()
        {
            MessageBox.Show(
                "¡Inicio de sesión exitoso!",
                "Bienvenido",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        public static void MostrarError(string mensaje)
        {
            MessageBox.Show(
                mensaje,
                "Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error
            );
        }

        public static void MostrarAdvertencia(string mensaje)
        {
            MessageBox.Show(
                mensaje,
                "Advertencia",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning
            );
        }

        public static DialogResult MostrarConfirmacion(string mensaje)
        {
            return MessageBox.Show(
                mensaje,
                "Confirmación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );
        }
    }
}
