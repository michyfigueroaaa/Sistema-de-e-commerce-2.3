﻿using Sistema_de_e_commerce.models;
using Sistema_de_e_commerce.repository;
using Sistema_de_e_commerce.utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace Sistema_de_e_commerce
{
    public partial class Form2 : Form
    {
        UsuariosRepository usariosRepository;
        ContraseniaRepository contraseniaRepository;
        public Form2()
        {
            InitializeComponent();
        }

        private void txtRegresar_Click(object sender, EventArgs e)
        {
            Form1 nuevoFormulario = new Form1(); // Crear instancia del nuevo form
            nuevoFormulario.Show();              // Mostrar el nuevo form
            this.Hide();                         // Opcional: ocultar el actual

        }

        private async void txtAgregar_Click(object sender, EventArgs e)
        {
            //Creacion de repositorios a utilizar
            usariosRepository = new UsuariosRepository();
            contraseniaRepository = new ContraseniaRepository();

            //Toma de datos de los TextBox
            string nombre = txtNombre.Text.Trim();
            string email = txtEmail.Text.Trim();
            string contraseniaTxt = txtContra.Text.Trim();

            //Verificacion de datos tomados
            if (String.IsNullOrWhiteSpace(email) || String.IsNullOrWhiteSpace(contraseniaTxt))
            {
                MessageBoxHelper.MostrarAdvertencia("Por favor, no deje campos vacios");
                return;
            }

            //Creación del ID de usuario
            if (nombre.Contains(" ") == false)
            {
                MessageBoxHelper.MostrarAdvertencia("Por favor, ingrese 1 nombre y 1 apellido como mínimo");
                return;
            }
            string id = GenerarIdUsuario(txtNombre.Text);
          

            //Verificar que el ID creado sea único
            if(id != null)
            {
                try
                {
                    Usuarios usuarioIdCoincidencia = await usariosRepository.ObtenerPorIdAsync(id);
                    while (usuarioIdCoincidencia != null)
                    {
                        id = GenerarIdUsuario(txtNombre.Text);
                        usuarioIdCoincidencia = await usariosRepository.ObtenerPorIdAsync(id);
                    }
                }catch
                {
                    MessageBoxHelper.MostrarAdvertencia("Ha habido problemas en la conexión. Por favor, intentelo luego.");
                    return;
                }

            }
            else
            {
                MessageBoxHelper.MostrarAdvertencia("Se ha producido un error al crear su ID de Usuario");
                return;
            }

            //Verificar que el EMAIL creado sea único
            try
            {
                Usuarios usuarioIdCoincidencia = await usariosRepository.ObtenerPorEmailAsync(email);
                if (usuarioIdCoincidencia != null)
                {
                    MessageBoxHelper.MostrarAdvertencia("Este correo ya esta en uso. Por favor intente con otro.");
                    return;
                }
            }
            catch
            {
                MessageBoxHelper.MostrarAdvertencia("Ha habido problemas en la conexión. Por favor, intentelo luego.");
                return;
            }

            // Crear nuevo usuario y asignarle datos
            var usuario = new Usuarios
             {
                 idUsuario = id,
                 nombre = nombre,
                 email = email
             };

            // Crear nueva contraseña y asignarle datos
            var contrasenia = new Contrasenia
            {
                entidadTipo = "usuario",
                entidadId = usuario.idUsuario,
                hash = ContraseniaHelper.GenerarHashSHA256(contraseniaTxt),
                esActiva = true,
            };

            try // Intentar añadir los datos a la base de datos
            { 
            await usariosRepository.AgregarAsync(usuario);
            await contraseniaRepository.InsertarContrasenia(contrasenia);
                MessageBox.Show("Usuario añadido exitosamente", "¡Bienvenido!", MessageBoxButtons.OK);
                LimpiarCampos();
            }
           catch (Exception ex) // Excepción para mostrar mensaje si hay problemas de conexion a la base
            {
                MessageBoxHelper.MostrarAdvertencia("Ha habido problemas en la conexión. Por favor, intentelo luego.");
                return;
           }

        }
       
        private static readonly Random random = new Random();

        private static string GenerarIdUsuario(string name)
        {
            char[] iniciales = ObtenerIniciales(name);
            if (iniciales == null)
            {
                MessageBoxHelper.MostrarAdvertencia("Por favor ingrese 1 nombre y 1 apellido minimo");
                return null;
            }
            else
            {
                // Generar tres números aleatorios
                int numero = random.Next(0, 1000);
                string numeroFormateado = numero.ToString("D3");

                // Concatenar letras y número
                return $"{iniciales[0]}{iniciales[1]}{numeroFormateado}";
            }
        }

        public static char[] ObtenerIniciales(string name)
        {
            name = name.ToUpper();
            name = name.Trim(); // Eliminar espacios extra

            if (name.Contains(" "))
            {
                // Dividir string por espacios
                var palabras = name.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if (palabras.Length >= 2)
                {
                    // Tomar la primera letra de dos primeras palabras
                    char[] inciales = new char[palabras.Length];
                    inciales[0] = palabras[0][0];
                    inciales[1] = palabras[1][0];
                    return inciales;
                }
                else
                {
                    return null;
                }
            }
            else
            {          
                return null;
            }

        }

        private void LimpiarCampos()
        {
            txtNombre.Text = "";
            txtEmail.Text = "";
            txtContra.Text = "";
        }
    }
}
