﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_e_commerce
{
    public partial class Form6 : Form
    {
        private string usuarioActualID;
        private int carritoID;
        private decimal totalCompra;

        public Form6(string usuarioActualID, int carritoID, decimal totalCompra)
        {
            InitializeComponent();
            this.usuarioActualID = usuarioActualID;
            this.carritoID = carritoID;
            this.totalCompra = totalCompra;
        }

        private void Form6_Load(object sender, EventArgs e)
        {         
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 formEstado = new Form7(usuarioActualID, -1); // -1 si aún no hay pedido
            formEstado.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 formCatalogo = new Form5();
            formCatalogo.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!ValidarTarjetaCredito()) return;

            int pedidoId = CrearPedido();

            if (pedidoId > 0 && TransferirProductosAlPedido(pedidoId))
            {
                ActualizarStock();
                FinalizarCompra(pedidoId);
            }
        }

        private bool ValidarTarjetaCredito()
        {
            string numTarjeta = textBox1.Text.Trim().Replace(" ", "");
            if (!Regex.IsMatch(numTarjeta, @"^\d{16}$"))
            {
                MessageBox.Show("El número de tarjeta debe tener 16 dígitos.");
                return false;
            }

            string fechaVencimiento = textBox3.Text.Trim();
            if (!Regex.IsMatch(fechaVencimiento, @"^(0[1-9]|1[0-2])\/(\d{2}|\d{4})$"))
            {
                MessageBox.Show("Formato de fecha inválido. Use MM/YY o MM/YYYY.");
                return false;
            }

            var partes = fechaVencimiento.Split('/');
            int mes = int.Parse(partes[0]);
            int anio = int.Parse(partes[1]);
            if (anio < 100) anio += 2000;

            DateTime fechaActual = DateTime.Now;
            if (anio < fechaActual.Year || (anio == fechaActual.Year && mes < fechaActual.Month))
            {
                MessageBox.Show("La tarjeta está vencida.");
                return false;
            }

            string cvv = txtCVV.Text.Trim();
            if (!Regex.IsMatch(cvv, @"^\d{3,4}$"))
            {
                MessageBox.Show("El CVV debe tener 3 o 4 dígitos.");
                return false;
            }

            return true;
        }

        private int CrearPedido()
        {
            try
            {
                string consulta = @"
                INSERT INTO pedidos (cliente_id, fecha, estado, direccion_envio, metodo_pago, total)
                VALUES (@ClienteId, GETDATE(), 'Pendiente', @Direccion, @MetodoPago, @Total);
                SELECT SCOPE_IDENTITY();";

                using (SqlConnection conexion = ConexionBD.ObtenerConexion())
                {
                    SqlCommand comando = new SqlCommand(consulta, conexion);
                    comando.Parameters.AddWithValue("@ClienteId", usuarioActualID);
                    comando.Parameters.AddWithValue("@Direccion", "Dirección predeterminada");
                    comando.Parameters.AddWithValue("@MetodoPago", "Tarjeta de Crédito");
                    comando.Parameters.AddWithValue("@Total", totalCompra);

                    conexion.Open();
                    return Convert.ToInt32(comando.ExecuteScalar());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear el pedido: " + ex.Message);
                return -1;
            }
        }

        private bool TransferirProductosAlPedido(int pedidoId)
        {
            try
            {
                string consulta = @"
                INSERT INTO detalle_pedidos (pedido_id, producto_id, cantidad, precio_unitario)
                SELECT @PedidoId, producto_id, cantidad, precio
                FROM items_carrito
                WHERE carrito_id = @CarritoId";

                SqlParameter[] parametros = new SqlParameter[]
                {
                    new SqlParameter("@PedidoId", pedidoId),
                    new SqlParameter("@CarritoId", carritoID)
                };

                return ConexionBD.EjecutarConsulta(consulta, parametros);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al transferir productos: " + ex.Message);
                return false;
            }
        }

        private void ActualizarStock()
        {
            try
            {
                string consulta = @"
                UPDATE productos
                SET stock = stock - c.cantidad
                FROM productos p
                INNER JOIN items_carrito c ON p.id = c.producto_id
                WHERE c.carrito_id = @CarritoId";

                SqlParameter[] parametros = new SqlParameter[]
                {
                    new SqlParameter("@CarritoId", carritoID)
                };

                ConexionBD.EjecutarConsulta(consulta, parametros);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el stock: " + ex.Message);
            }
        }

        private void FinalizarCompra(int pedidoId)
        {
            try
            {
                string consulta = "UPDATE carritos SET estado = 'Finalizado' WHERE id = @Id";
                SqlParameter[] parametros = new SqlParameter[]
                {
                    new SqlParameter("@Id", carritoID)
                };

                ConexionBD.EjecutarConsulta(consulta, parametros);

                MessageBox.Show("¡Compra realizada con éxito!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Form7 estado = new Form7(usuarioActualID, pedidoId);
                estado.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al finalizar la compra: " + ex.Message);
            }
        }
    }
}

