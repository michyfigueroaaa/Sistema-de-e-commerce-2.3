﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce
{
   public static class CarritoGlobal
    {
        public static List<ItemCarrito> Items { get; private set; } = new List<ItemCarrito>();

        public static void AgregarItem(ItemCarrito item)
        {
            Items.Add(item);
        }

        public static void LimpiarCarrito()
        {
            Items.Clear();
        }

        public static decimal CalcularTotal()
        {
            return Items.Sum(i => i.Total);
        }
    }
}

