﻿using Sistema_de_e_commerce.models;
using Sistema_de_e_commerce.repository;
using Sistema_de_e_commerce.utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_e_commerce
{
    public partial class Form1 : Form
    {
        UsuariosRepository usuariosRepository;
        ContraseniaRepository contraseniaRepository;
        TrabajadoresRepository trabajadoresRepository;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 nuevoFormulario = new Form2(); // Crear instancia del nuevo form
            nuevoFormulario.Show();              // Mostrar el nuevo form
            this.Hide();                         // Opcional: ocultar el actual

        }

        private async void btnIngresar_Click(object sender, EventArgs e)
        {
            string correo = txtCorreo.Text.Trim();
            string contra = txtContra1.Text.Trim();

            usuariosRepository = new UsuariosRepository();
            contraseniaRepository = new ContraseniaRepository();
            trabajadoresRepository = new TrabajadoresRepository();

            //Validación de datos ingresados
            if (String.IsNullOrWhiteSpace(correo) || String.IsNullOrWhiteSpace(contra))
            {
                MessageBoxHelper.MostrarAdvertencia("Por favor, no deje campos vacios");
                return;
            }

            try
            {
                //Determinar si el texto ingresado tiene el 
                bool esTrabajador = esIdTrabajador(correo);
                string contraCifr = ContraseniaHelper.GenerarHashSHA256(contra);

                if (esTrabajador)
                {
                    try
                    {
                        //Llamar registros de cuenta del empleado
                        var trabajador = await trabajadoresRepository.ObtenerPorIdAsync(correo);
                        if (trabajador == null)
                        {
                            MessageBoxHelper.MostrarAdvertencia("Las credenciales que usted ingreso no han sido encontradas en nuestros registros");
                            return;
                        }

                        //Llamar registros de contraseña del empleado
                        var contrasenia = await contraseniaRepository.ObtenerPorEntidadIdAsync(correo); 
                        if (contrasenia == null)
                        {
                            MessageBoxHelper.MostrarAdvertencia("Los datos ingresados no coinciden con nuestros registros. Por favor, revise que haya ingresado sus datos correctamente");
                            return;
                        }

                        //Verificacion de contraseña
                        if (contrasenia.hash != contraCifr)
                        {
                            MessageBoxHelper.MostrarAdvertencia("Los datos ingresados no coinciden con nuestros registros. Por favor, revise que haya ingresado sus datos correctamente");
                            return;
                        }

                        MessageBoxHelper.MostrarLoginExitoso();
                        Form3 nuevoFormulario = new Form3(); // Crear instancia del nuevo form
                        nuevoFormulario.Show();              // Mostrar el nuevo form
                        this.Hide();                         // Opcional: ocultar el actual
                    }
                    catch (Exception ex)
                    {
                        MessageBoxHelper.MostrarAdvertencia("Estamos teniendo problemas en la conexión. Por favor, intente acceder luego.");
                        return;
                    }
                } else
                {
                    try
                    {
                        //Llamar registros de cuenta del empleado
                        var usuario = await usuariosRepository.ObtenerPorEmailAsync(correo);
                        if (usuario == null)
                        {
                            MessageBoxHelper.MostrarAdvertencia("El Email que usted ingreso no ha sido encontrado en nuestros registros");
                            return;
                        }

                        //Llamar registros de contraseña del empleado
                        var contrasenia = await contraseniaRepository.ObtenerPorEntidadIdAsync(usuario.idUsuario);
                        if (contrasenia == null)
                        {
                            MessageBoxHelper.MostrarAdvertencia("Los datos ingresados no coinciden con nuestros registros. Por favor, revise que haya ingresado sus datos correctamente");
                            return;
                        }

                        //Verificacion de contraseña
                        if (contrasenia.hash != contraCifr)
                        {
                            MessageBoxHelper.MostrarAdvertencia("Los datos ingresados no coinciden con nuestros registros. Por favor, revise que haya ingresado sus datos correctamente");
                            return;
                        }

                        MessageBoxHelper.MostrarLoginExitoso();
                        Form5 nuevoFormulario = new Form5(usuario.idUsuario, "cliente"); // Crear instancia del nuevo form
                        nuevoFormulario.Show();              // Mostrar el nuevo form
                        this.Hide();                         // Opcional: ocultar el actual
                    }
                    catch (Exception ex)
                    {
                        MessageBoxHelper.MostrarAdvertencia("Estamos teniendo problemas en la conexión. Por favor, intente acceder luego.");
                        return;
                    }
                }          
            }
            catch
            {
                MessageBox.Show("Ha habido problemas en la conexión. Por favor, intentelo luego.", "ADVERTENCIA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }
        }

        static bool esIdTrabajador(string codigo)
        {
            string patron = @"^[a-zA-Z]{2}[0-9]{3}$";
            return Regex.IsMatch(codigo, patron);
        }
    }
}
