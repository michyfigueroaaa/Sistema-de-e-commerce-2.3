﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_de_e_commerce.models
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Categoria { get; set; }
        public string Estilo { get; set; }
        public string Talla { get; set; }
        public string Color { get; set; }
        public decimal Precio { get; set; }
        public int Cantidad { get; set; } // Para el stock
    }

    public class ItemCarrito
    {
        public int Id { get; set; }
        public int CarritoId { get; set; }
        public int ProductoId { get; set; }
        public string NombreProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio { get; set; }
        public decimal Total => Cantidad * Precio;
    }

    public class Carrito
    {
        public int Id { get; set; }
        public string ClienteId { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string Estado { get; set; }
    }

    public class Pedido
    {
        public int Id { get; set; }
        public string ClienteId { get; set; }
        public DateTime Fecha { get; set; }
        public string Estado { get; set; }
        public string DireccionEnvio { get; set; }
        public string MetodoPago { get; set; }
        public decimal Total { get; set; }
    }

    public class Usuario
    {
        public string IdUsuario { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
    }

}
