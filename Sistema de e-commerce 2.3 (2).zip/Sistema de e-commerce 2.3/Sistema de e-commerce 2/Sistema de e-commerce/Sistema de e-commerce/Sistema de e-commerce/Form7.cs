﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sistema_de_e_commerce
{
    public partial class Form7 : Form
    {
        private int pedidoSeleccionadoID = -1;
        private string usuarioActualID;

        public Form7()
        {
            InitializeComponent();
            
        }

        public Form7(string usuarioActualID, int pedidoID = -1)
        {
            InitializeComponent();
            this.usuarioActualID = usuarioActualID;
            this.pedidoSeleccionadoID = pedidoID;
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            CargarPedidos();
            if (pedidoSeleccionadoID != -1)
            {
                comboBox1.SelectedValue = pedidoSeleccionadoID;
            }
        }

        private void CargarPedidos()
        {
            string consulta = @"
            SELECT id, fecha, estado, total
            FROM pedidos
            WHERE cliente_id = @ClienteId
            ORDER BY fecha DESC";

            SqlParameter[] parametros = new SqlParameter[]
            {
            new SqlParameter("@ClienteId", usuarioActualID)
            };

            DataTable dtPedidos = ConexionBD.EjecutarConsultaSelect(consulta, parametros);

            if (dtPedidos.Rows.Count == 0)
            {
                MessageBox.Show("No tienes pedidos realizados", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            comboBox1.DataSource = dtPedidos;
            comboBox1.DisplayMember = "id";
            comboBox1.ValueMember = "id";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue != null)
            {
                int pedidoId = Convert.ToInt32(comboBox1.SelectedValue);
                comboBox1.Text = pedidoId.ToString(); // Mostrar el ID en el TextBox
                CargarDetallePedido(pedidoId);
            }
        }

        private void CargarDetallePedido(int pedidoId)
        {
            string consultaPedido = @"
            SELECT p.id, p.fecha, p.estado, p.direccion_envio, p.metodo_pago, p.total
            FROM pedidos p
            WHERE p.id = @PedidoId AND p.cliente_id = @ClienteId";

            SqlParameter[] parametrosPedido = new SqlParameter[]
            {
            new SqlParameter("@PedidoId", pedidoId),
            new SqlParameter("@ClienteId", usuarioActualID)
            };

            DataTable infoPedido = ConexionBD.EjecutarConsultaSelect(consultaPedido, parametrosPedido);

            if (infoPedido.Rows.Count == 0) return;

            string consultaDetalle = @"
            SELECT dp.producto_id, p.nombre, dp.cantidad, dp.precio_unitario, (dp.cantidad * dp.precio_unitario) AS subtotal
            FROM detalle_pedidos dp
            JOIN productos p ON dp.producto_id = p.id
            WHERE dp.pedido_id = @PedidoId";

            SqlParameter[] parametrosDetalle = new SqlParameter[]
            {
            new SqlParameter("@PedidoId", pedidoId)
            };

            DataTable detalles = ConexionBD.EjecutarConsultaSelect(consultaDetalle, parametrosDetalle);
            dataGridView1.DataSource = infoPedido;

            /* (detalles != null)
            {
                dataGridView1.Columns["producto_id"].HeaderText = "ID Producto";
                dataGridView1.Columns["nombre"].HeaderText = "Producto";
                dataGridView1.Columns["cantidad"].HeaderText = "Cantidad";
                dataGridView1.Columns["precio_unitario"].HeaderText = "Precio Unitario";
                dataGridView1.Columns["subtotal"].HeaderText = "Subtotal";

                dataGridView1.Columns["precio_unitario"].DefaultCellStyle.Format = "C2";
                dataGridView1.Columns["subtotal"].DefaultCellStyle.Format = "C2";
            }*/
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancelarPedido_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null)
            {
                MessageBox.Show("Por favor, seleccione un pedido", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int pedidoId = Convert.ToInt32(comboBox1.SelectedValue);

            string consultaEstado = @"
            SELECT estado
            FROM pedidos
            WHERE id = @PedidoId AND cliente_id = @ClienteId";

            SqlParameter[] parametrosEstado = new SqlParameter[]
            {
            new SqlParameter("@PedidoId", pedidoId),
            new SqlParameter("@ClienteId", usuarioActualID)
            };

            DataTable resultadoEstado = ConexionBD.EjecutarConsultaSelect(consultaEstado, parametrosEstado);

            if (resultadoEstado != null && resultadoEstado.Rows.Count > 0)
            {
                string estado = resultadoEstado.Rows[0]["estado"].ToString();
                if (estado != "Pendiente")
                {
                    MessageBox.Show("Solo se pueden cancelar pedidos en estado 'Pendiente'", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DialogResult resultado = MessageBox.Show("¿Está seguro de cancelar este pedido?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    string consultaActualizar = @"
                    UPDATE pedidos
                    SET estado = 'Cancelado'
                    WHERE id = @PedidoId AND cliente_id = @ClienteId";

                    SqlParameter[] parametrosActualizar = new SqlParameter[]
                    {
                    new SqlParameter("@PedidoId", pedidoId),
                    new SqlParameter("@ClienteId", usuarioActualID)
                    };

                    bool actualizado = ConexionBD.EjecutarConsulta(consultaActualizar, parametrosActualizar);

                    if (actualizado)
                    {
                        MessageBox.Show("Pedido cancelado");
                        CargarPedidos();
                    }
                    else
                    {
                        MessageBox.Show("Error al cancelar el pedido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void DevolverProductosAlStock(int pedidoId)
        {
            try
            {
                string consultaDetalle = @"
                SELECT producto_id, cantidad
                FROM detalle_pedidos
                WHERE pedido_id = @PedidoId";

                SqlParameter[] parametrosDetalle = new SqlParameter[]
                {
                new SqlParameter("@PedidoId", pedidoId)
                };

                DataTable detalles = ConexionBD.EjecutarConsultaSelect(consultaDetalle, parametrosDetalle);

                foreach (DataRow fila in detalles.Rows)
                {
                    int productoId = Convert.ToInt32(fila["producto_id"]);
                    int cantidad = Convert.ToInt32(fila["cantidad"]);

                    string consultaActualizar = @"
                    UPDATE stock
                    SET cantidad = cantidad + @Cantidad
                    WHERE producto_id = @ProductoId";

                    SqlParameter[] parametrosActualizar = new SqlParameter[]
                    {
                    new SqlParameter("@ProductoId", productoId),
                    new SqlParameter("@Cantidad", cantidad)
                    };

                    ConexionBD.EjecutarConsulta(consultaActualizar, parametrosActualizar);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al devolver productos al stock: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Debes reemplazar 0 y 0m con los valores reales que tengas para pedidoID y total, o con valores predeterminados si no los tienes aún.
            int pedidoID = 0;      // ejemplo, cambia al valor correcto
            decimal total = 0m;    // ejemplo, cambia al valor correcto

            Form5 nuevoFormulario = new Form5(usuarioActualID, "string");
            nuevoFormulario.Show();
            this.Hide();
        }

    }
}

