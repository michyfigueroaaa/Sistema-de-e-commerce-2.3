﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sistema_de_e_commerce;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sistema_de_e_commerce
{
    public partial class Form5 : Form
    {
        private string usuarioActualID;
        private List<Producto> productosDisponibles = new List<Producto>();
        private List<ItemCarrito> itemsCarrito = new List<ItemCarrito>();
        private string idUsuario;
        private int ObtenerCarritoActivo() { return 0; }
        private bool AgregarProductoAlCarrito(int carritoId, int productoId, int cantidad, decimal precio)
        {

            return true;
        }
        public Form5(string usuario, string v)
        {
            InitializeComponent();
            usuarioActualID = idUsuario;
            comboBox1.SelectedIndexChanged += (s, e) => CargarProductosFiltrados();
            comboBox2.SelectedIndexChanged += (s, e) => CargarProductosFiltrados();
            numericUpDown1.ValueChanged += (s, e) => CargarProductosFiltrados();

        }

        public Form5()
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
           


        }

        private void Form5_Load(object sender, EventArgs e)
        {
            CargarCategorias();
            CargarEstilos();
            CargarProductosFiltrados();
            comboBox1.Items.AddRange(new string[] { "Todas", "Mujer", "Unisex" });
            comboBox1.SelectedIndex = 0;

            comboBox2.Items.AddRange(new string[] { "Todos", "Casuales", "Deportivos", "Sandalias" });
            comboBox2.SelectedIndex = 0;

            numericUpDown1.Minimum = 0;
            numericUpDown1.Maximum = 50;
            numericUpDown1.Value = 0;

            CargarProductosFiltrados(); // mostrar todo al iniciar

        }

        private void CargarCategorias()
        {
            string consulta = "SELECT DISTINCT categoria FROM productos WHERE categoria IS NOT NULL";

            try
            {
                DataTable categorias = ConexionBD.EjecutarConsultaSelect(consulta);
                if (categorias != null)
                {
                    comboBox1.Items.Clear();
                    comboBox1.Items.Add("Todas"); // Opción por defecto

                    foreach (DataRow fila in categorias.Rows)
                    {
                        comboBox1.Items.Add(fila["categoria"].ToString());
                    }

                    comboBox1.SelectedIndex = 0;
                }
            }
            catch(Exception ex) {
            
                    Console.WriteLine("ERRO DE CONEXCION " + ex);
            }
        
        }
        private void CargarEstilos()
        {
            string consulta = "SELECT DISTINCT estilo FROM productos WHERE estilo IS NOT NULL";

            DataTable estilos = ConexionBD.EjecutarConsultaSelect(consulta);
            if (estilos != null)
            {
                comboBox2.Items.Clear();
                comboBox2.Items.Add("Todos");
                foreach (DataRow fila in estilos.Rows)
                {
                    comboBox2.Items.Add(fila["estilo"].ToString());
                }

                comboBox2.SelectedIndex = 0;
            }
        }

        private void CargarProductosFiltrados()
        {
            string consulta = @"
        SELECT 
            p.id,
            p.nombre,
            p.descripcion,
            p.categoria,
            p.estilo,
            p.talla,
            p.color,
            p.precio,
            s.cantidad
        FROM 
            productos p
        JOIN 
            stock s ON p.id = s.producto_id
        WHERE 
            (@Categoria = 'Todas' OR p.categoria = @Categoria)
            AND (@Estilo = 'Todos' OR p.estilo = @Estilo)
            AND (@Talla = 0 OR p.talla = @Talla)
    ";

            string categoria = comboBox1.SelectedItem?.ToString() ?? "Todas";
            string estilo = comboBox2.SelectedItem?.ToString() ?? "Todos";
            int talla = (int)numericUpDown1.Value;

            SqlParameter[] parametros = new SqlParameter[]
            {
        new SqlParameter("@Categoria", categoria),
        new SqlParameter("@Estilo", estilo),
        new SqlParameter("@Talla", talla)
            };

            DataTable productos = ConexionBD.EjecutarConsultaSelect(consulta, parametros);
            dataGridView1.DataSource = productos;
        }



        void ActualizarGridProductos()
            {
                string categoriaSeleccionada = comboBox1.SelectedItem.ToString();
                string estiloSeleccionado = comboBox2.SelectedItem.ToString();

                var productosFiltrados = productosDisponibles;

                if (categoriaSeleccionada != "Todas")
                {
                    productosFiltrados = productosFiltrados.FindAll(p => p.Categoria == categoriaSeleccionada);
                }
                if (estiloSeleccionado != "Todos")
                {
                    productosFiltrados = productosFiltrados.FindAll(p => p.Estilo == estiloSeleccionado);
                }
                DataTable tabla = new DataTable();
                tabla.Columns.Add("ID", typeof(int));
                tabla.Columns.Add("Nombre", typeof(string));
                tabla.Columns.Add("Categoría", typeof(string));
                tabla.Columns.Add("Estilo", typeof(string));
                tabla.Columns.Add("Talla", typeof(string));
                tabla.Columns.Add("Color", typeof(string));
                tabla.Columns.Add("Precio", typeof(decimal));
                tabla.Columns.Add("Stock", typeof(int));
                foreach (var producto in productosFiltrados)
                {
                    tabla.Rows.Add(
                        producto.Id,
                        producto.Nombre,
                        producto.Categoria,
                        producto.Estilo,
                        producto.Talla,
                        producto.Color,
                        producto.Precio,
                        producto.Cantidad
                    );
                }
                dataGridView1.DataSource = tabla;
            }
            void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
            {
                ActualizarGridProductos();
            }
            void btnAgregarCarrito_Click(object sender, EventArgs e)
            {
                // Verificar si hay una fila seleccionada
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Por favor, seleccione un producto", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                int productoId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

                // Obtener la cantidad seleccionada
                int cantidad = Convert.ToInt32(numericUpDown2.Value);

                if (cantidad <= 0)
                {
                    MessageBox.Show("La cantidad debe ser mayor a 0", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                Producto productoSeleccionado = productosDisponibles.Find(p => p.Id == productoId);

                if (productoSeleccionado == null || productoSeleccionado.Cantidad < cantidad)
                {
                    MessageBox.Show("No hay suficiente stock disponible", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                int carritoId = ObtenerCarritoActivo();

                if (carritoId == -1)
                {

                    if (ObtenerCarritoActivo() == -1)
                    {
                        MessageBox.Show("Error al crear el carrito", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    bool resultado = AgregarProductoAlCarrito(ObtenerCarritoActivo(), productoId, cantidad, productoSeleccionado.Precio);

                    if (resultado)
                    {
                        MessageBox.Show("Producto agregado al carrito correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        productoSeleccionado.Cantidad -= cantidad;


                        ActualizarGridProductos();
                    }
                    else
                    {
                        MessageBox.Show("Error al agregar el producto al carrito", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            

        private int CrearNuevoCarrito()
        {
            string consulta = @"
        INSERT INTO carritos (cliente_id, fecha_creacion, estado)
        VALUES (@ClienteId, GETDATE(), 'Activo');
        SELECT SCOPE_IDENTITY();";

            SqlParameter[] parametros = new SqlParameter[]
            {
        new SqlParameter("@ClienteId", usuarioActualID)
            };

            try
            {
                using (SqlConnection conexion = ConexionBD.ObtenerConexion())
                {
                    conexion.Open();
                    using (SqlCommand comando = new SqlCommand(consulta, conexion))
                    {
                        comando.Parameters.AddRange(parametros);
                        object resultado = comando.ExecuteScalar();

                        if (resultado != null && resultado != DBNull.Value)
                        {
                            return Convert.ToInt32(resultado);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear el carrito: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return -1;
            bool AgregarProductoAlCarrito(int carritoId, int productoId, int cantidad, decimal precio)
            {

                string consultaVerificar = @"
                SELECT id, cantidad 
                FROM items_carrito 
                WHERE carrito_id = @CarritoId AND producto_id = @ProductoId";

                SqlParameter[] parametrosVerificar = new SqlParameter[]
                {
                new SqlParameter("@CarritoId", carritoId),
                new SqlParameter("@ProductoId", productoId)
                };
                DataTable resultadoVerificar = ConexionBD.EjecutarConsultaSelect(consultaVerificar, parametrosVerificar);

                if (resultadoVerificar != null && resultadoVerificar.Rows.Count > 0)
                {
                    // El producto ya está en el carrito, actualizar la cantidad
                    int idItem = Convert.ToInt32(resultadoVerificar.Rows[0]["id"]);
                    int cantidadActual = Convert.ToInt32(resultadoVerificar.Rows[0]["cantidad"]);
                    int nuevaCantidad = cantidadActual + cantidad;
                    string consultaActualizar = @"
                    UPDATE items_carrito 
                    SET cantidad = @Cantidad 
                    WHERE id = @Id";

                    SqlParameter[] parametrosActualizar = new SqlParameter[]
                        {
                    new SqlParameter("@Cantidad", nuevaCantidad),
                    new SqlParameter("@Id", idItem)
                };
                    return ConexionBD.EjecutarConsulta(consultaActualizar, parametrosActualizar);
                }
                else
                {
                    string consultaInsertar = @"
                    INSERT INTO items_carrito (carrito_id, producto_id, cantidad, precio)
                    VALUES (@CarritoId, @ProductoId, @Cantidad, @Precio)";

                    SqlParameter[] parametrosInsertar = new SqlParameter[]
                    {
                         new SqlParameter("@CarritoId", carritoId),
                    new SqlParameter("@ProductoId", productoId),
                    new SqlParameter("@Cantidad", cantidad),
                    new SqlParameter("@Precio", precio)
                };
                    return ConexionBD.EjecutarConsulta(consultaInsertar, parametrosInsertar);
                }
            }

            void btnVisualizarCarrito_Click(object sender, EventArgs e)
            {
                
            }


        }
        private void FiltrarProductos()
        {
            string categoria = comboBox1.SelectedItem?.ToString();
            string estilo = comboBox2.SelectedItem?.ToString();
            string talla = numericUpDown1.Value.ToString(); // por ejemplo, 38
                                                            // nota: la talla en la BD es CHAR(4), por lo que se puede convertir a string directamente

            List<SqlParameter> parametros = new List<SqlParameter>();
            string consulta = @"
        SELECT * 
        FROM vw_ProductosDisponiblesCliente
        WHERE 1 = 1"; // para facilitar el agregado de filtros opcionales

            if (!string.IsNullOrEmpty(categoria))
            {
                consulta += " AND categoria = @categoria";
                parametros.Add(new SqlParameter("@categoria", categoria));
            }

            if (!string.IsNullOrEmpty(estilo))
            {
                consulta += " AND estilo = @estilo";
                parametros.Add(new SqlParameter("@estilo", estilo));
            }

            if (!string.IsNullOrEmpty(talla))
            {
                consulta += " AND talla = @talla";
                parametros.Add(new SqlParameter("@talla", talla));
            }

            DataTable resultado = ConexionBD.EjecutarConsultaSelect(consulta, parametros.ToArray());
            dataGridView1.DataSource = resultado;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            FiltrarProductos();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            FiltrarProductos();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            FiltrarProductos();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            FiltrarProductos();
        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un producto.");
                return;
            }

            DataGridViewRow fila = dataGridView1.SelectedRows[0];

            int productoId = Convert.ToInt32(fila.Cells["id"].Value);
            string nombre = fila.Cells["nombre"].Value.ToString();
            decimal precio = Convert.ToDecimal(fila.Cells["precio"].Value);
            int cantidad = (int)numericUpDown2.Value;

            if (cantidad <= 0)
            {
                MessageBox.Show("Ingresa una cantidad válida.");
                return;
            }

            // Crear el ítem
            ItemCarrito item = new ItemCarrito
            {
                ProductoId = productoId,
                NombreProducto = nombre,
                Precio = precio,
                Cantidad = cantidad
            };

            // Agregarlo al carrito global
            CarritoGlobal.AgregarItem(item);

            // Abrir Form8 mostrando todos los ítems actuales del carrito
            Form8 carritoForm = new Form8();
            carritoForm.Show();
            this.Hide(); // opcional
        }

    }
}
