﻿using Sistema_de_e_commerce.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using Sistema_de_e_commerce;
using System.Windows.Forms;
using static Sistema_de_e_commerce.Form5;

namespace Sistema_de_e_commerce
{
    public partial class Form8 : Form
    {
        private List<ItemCarrito> itemsCarrito = new List<ItemCarrito>();

        public Form8()
        {
            InitializeComponent();
            itemsCarrito = CarritoGlobal.Items;
            CargarItemsCarrito();
        }

        private void CargarItemsCarrito()
        {
            DataTable tabla = new DataTable();
            tabla.Columns.Add("Producto");
            tabla.Columns.Add("Cantidad");
            tabla.Columns.Add("Precio");
            tabla.Columns.Add("Total");

            foreach (var item in itemsCarrito)
            {
                tabla.Rows.Add(item.NombreProducto, item.Cantidad, item.Precio, item.Total);
            }

            DataGridview1.DataSource = tabla;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (CarritoGlobal.Items.Count == 0)
            {
                MessageBox.Show("El carrito está vacío.");
                return;
            }

            try
            {
                string usuarioID = "AF021"; // O el valor real que viene desde login
                if (string.IsNullOrEmpty(usuarioID) || usuarioID.Length > 5)
                {
                    MessageBox.Show("ID de usuario inválido.");
                    return;
                }

                decimal total = CarritoGlobal.CalcularTotal();

                // Aquí puedes obtener estos datos de tu formulario
                string direccionEnvio = "Mi dirección de envío"; // Cambiar por dato real
                string metodoPago = "Tarjeta"; // Cambiar por dato real

                using (SqlConnection conexion = ConexionBD.ObtenerConexion())
                {
                    conexion.Open();
                    SqlTransaction transaction = conexion.BeginTransaction();

                    try
                    {
                        string consultaPedido = @"
                    INSERT INTO pedidos (cliente_id, fecha, total, estado, direccion_envio, metodo_pago)
                    VALUES (@ClienteId, GETDATE(), @Total, 'Pendiente', @DireccionEnvio, @MetodoPago);
                    SELECT SCOPE_IDENTITY();";

                        SqlCommand cmd = new SqlCommand(consultaPedido, conexion, transaction);
                        cmd.Parameters.AddWithValue("@ClienteId", usuarioID);
                        cmd.Parameters.AddWithValue("@Total", total);
                        cmd.Parameters.AddWithValue("@DireccionEnvio", direccionEnvio);
                        cmd.Parameters.AddWithValue("@MetodoPago", metodoPago);

                        int pedidoId = Convert.ToInt32(cmd.ExecuteScalar());

                        string consultaDetalle = @"
                    INSERT INTO detalle_pedidos (pedido_id, producto_id, cantidad, precio_unitario)
                    VALUES (@PedidoId, @ProductoId, @Cantidad, @Precio)";

                        foreach (var item in CarritoGlobal.Items)
                        {
                            SqlCommand cmdDetalle = new SqlCommand(consultaDetalle, conexion, transaction);
                            cmdDetalle.Parameters.AddWithValue("@PedidoId", pedidoId);
                            cmdDetalle.Parameters.AddWithValue("@ProductoId", item.ProductoId);
                            cmdDetalle.Parameters.AddWithValue("@Cantidad", item.Cantidad);
                            cmdDetalle.Parameters.AddWithValue("@Precio", item.Precio);
                            cmdDetalle.ExecuteNonQuery();
                        }

                        transaction.Commit();

                        CarritoGlobal.LimpiarCarrito();

                        Form6 pagoForm = new Form6(usuarioID, pedidoId, total);
                        pagoForm.Show();
                        this.Hide();
                    }
                    catch (Exception exTrans)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Error al procesar el pedido (transacción): " + exTrans.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al procesar el pedido: " + ex.Message);
            }
        }
        public void RegistrarPago(string clienteId, decimal monto, string metodoPago)
        {
            string connectionString = "TU_CADENA_DE_CONEXION_AQUI";

            string consulta = @"
        INSERT INTO pagos (cliente_id, monto, metodoPago)
        VALUES (@ClienteId, @Monto, @MetodoPago)";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    using (SqlCommand cmd = new SqlCommand(consulta, conexion))
                    {
                        cmd.Parameters.AddWithValue("@ClienteId", clienteId);
                        cmd.Parameters.AddWithValue("@Monto", monto);
                        cmd.Parameters.AddWithValue("@MetodoPago", metodoPago ?? (object)DBNull.Value);

                        int filasAfectadas = cmd.ExecuteNonQuery();
                        if (filasAfectadas > 0)
                        {
                            Console.WriteLine("Pago registrado con éxito.");
                        }
                        else
                        {
                            Console.WriteLine("No se pudo registrar el pago.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al registrar el pago: " + ex.Message);
            }
        }

        private decimal CalcularTotalDesdeDataGridView()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in DataGridview1.Rows)
            {
                if (row.Cells["Total"].Value != null)
                {
                    total += Convert.ToDecimal(row.Cells["Total"].Value);
                }
            }
            return total;
        }

        private decimal CalcularTotal()
        {
            return itemsCarrito.Sum(item => item.Total);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            

        }

        private void Form8_Load(object sender, EventArgs e)
        {
           
        }
        

    }
}
